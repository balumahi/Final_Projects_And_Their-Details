package com.capgemini.hms.controller;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.hms.Exception.HotelException;
import com.capgemini.hms.dto.BookingDetails;
import com.capgemini.hms.dto.Hotel;
import com.capgemini.hms.dto.RoomDetails;
import com.capgemini.hms.dto.Users;
import com.capgemini.hms.service.HotelServiceImpl;
import com.capgemini.hms.service.IHotelService;


@WebServlet("*.hb")
public class HotelController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletConfig  conf;
	IHotelService hotelService;
    
    
    public HotelController()
    {
    	hotelService=new HotelServiceImpl();
          
        }
        
	
	

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String url="" ;
		String action = request.getServletPath();			
		
		switch (action)
		{
		case "/login.hb":
			
			String username= request.getParameter("txtUnm");
			String password= request.getParameter("txtPwd");
			
			if(username.equals("admin") && password.equals("admin"))
			{
				url="AdminIndex.jsp";
			}
			else
			{
				url="ErrorPage.jsp";
				
				
			}
			break;
				
			
			


		case "/addHotel.hb":
			String city = request.getParameter("city");
			String hotelName =request.getParameter("hotelName");
			String addressHotel = request.getParameter("address");
			String description = request.getParameter("description");
			String rate = request.getParameter("nightRate");
			
			//System.out.println(rate);
			//int Rate=Integer.parseInt(rate);
			Float nightRate = Float.parseFloat(rate);
			String phoneOne = request.getParameter("phoneOne");
			String phoneTwo = request.getParameter("phoneTwo");
			String rating = request.getParameter("rating");
			String emailHotel = request.getParameter("email");
			String fax = request.getParameter("fax");
			
			Hotel hotel = new Hotel();
			
			hotel.setCity(city);
			hotel.setHotelName(hotelName);
			hotel.setAddress(addressHotel);
			hotel.setDescription(description);;
			hotel.setAvgRatePerNight(nightRate);
			hotel.setPhoneNo1(phoneOne);
			hotel.setPhoneNo2(phoneTwo);
			hotel.setRating(rating);;
			hotel.setEmail(emailHotel);
			hotel.setFax(fax);
			
			try 
			{
				hotelService.addHotel(hotel);
			}
			catch (HotelException e) 
			{
				request.getSession().setAttribute("error", e.getMessage());
				e.printStackTrace();
			}
			
			HttpSession sessionH = request.getSession();
			sessionH.setAttribute("hotel",hotel);
			
			url="Success.jsp";
			break;
			
		case "/ViewHotel.hb":
		List<Hotel>hlist=hotelService.showAllHotels();
		request.setAttribute("hlist", hlist);
		url="ViewHotel.jsp";
		break;
		
		case "/RemoveHotel.hb":
			String hid=request.getParameter("hotelId");
			HttpSession sess=request.getSession(true);
			 System.out.println(sess);
			sess.setAttribute("hid", hid);
			hotelService.removeHotel(hid);
			url="Success.jsp";
			break;
			
		case "/viewBooking.hb":
			List<BookingDetails>blist=hotelService.showAllBookings();
			request.setAttribute("blist", blist);
			url="ViewBookingDetails.jsp";
			break;
			
		case "/viewRoom.hb":
			List<RoomDetails>Rdlist=hotelService.showAllRooms();
			request.setAttribute("Rdlist", Rdlist);
			url="ViewRoomDetails.jsp";
			
			break;
			
		case "/viewRoomuser.hb":
			List<RoomDetails>Rd1list=hotelService.showAllRooms();
			HttpSession session=request.getSession();
			session.setAttribute("Rd1list", Rd1list);
			url="UsersViewRoomDetails.jsp";
			break;
			
			
		case"/addRoom.hb":
			String hotelId = request.getParameter("hotelId");
			String roomNo =request.getParameter("roomNo");
			String roomType = request.getParameter("roomType");
			Float perNightRate = Float.parseFloat(request.getParameter("perNightRate"));
			String availability = request.getParameter("availability");
			String action1=request.getParameter("Action");
			
		
			RoomDetails room =new RoomDetails();
				
				room.setHotelId(hotelId);
			room.setRoomNo(roomNo);
			room.setRoomType(roomType);
			room.setPerNightRate(perNightRate);
			room.setAvailability(availability);
			room.setPhoto(action1);
			
/*			hotelService.addRoomDetails(room);
*/			
			try 
			{
			System.out.println(room);
				int roomid=hotelService.addRoomDetails(room);
				System.out.println(roomid);
			}
			catch (HotelException e) 
			{
				request.getSession().setAttribute("error", e.getMessage());
				e.printStackTrace();
			}
			
			HttpSession session1= request.getSession();
			session1.setAttribute("room",room);
			
			url="Success.jsp";
			break;
		case"/getRoomById.hb":
			String roomId1=request.getParameter("txtRoom");
			//HttpSession sess1=request.getSession(true);
			System.out.println("room id"+roomId1);
			RoomDetails roomDetails=hotelService.getRoomDetails(roomId1);
			System.out.println(roomDetails);
			//System.out.println(sess1);
			request.setAttribute("roomDetails", roomDetails);
			url="showRoomDetailsById.jsp";
			break;
			
		case "/getRoomdetails.hb":
			String roomId=request.getParameter("roomID");
			
			RoomDetails roomDetails1  = hotelService.getRoomDetails(roomId);
			
			request.setAttribute("roomDetails1",roomDetails1);
			url="UpdateRoomDetails.jsp";
			
			break;
			
		case "/processUpdate.hb":
			
			String hotelID = request.getParameter("hotelId");
			String roomID = request.getParameter("roomId");
			String roomNum = request.getParameter("roomNumber");
			String roomType1 = request.getParameter("roomType");
			String nightrate = request.getParameter("nightRate");
			Float nightRate1 =Float.parseFloat(nightrate);
			String available = request.getParameter("available");
			String action2 = request.getParameter("action");
			
			RoomDetails room1 = new RoomDetails();
			
			room1.setHotelId(hotelID);
			room1.setRoomId(roomID);
			room1.setRoomNo(roomNum);
			room1.setRoomType(roomType1);
			room1.setPerNightRate(nightRate1);
			room1.setAvailability(available);
			room1.setPhoto(action2);
			
		
			
		hotelService.updateRoomDetails(room1);
		
		url="Success.jsp";
			break;
			
		case "/getHoteldetails.hb":
			String hotelId1=request.getParameter("hotelID");
			
			Hotel hoteldetails  = hotelService.getHotelDetails(hotelId1);
			
			request.setAttribute("hoteldetails",hoteldetails);
			url="UpdateHotel.jsp";
			
			break;
			
		case "/processUpdateRoom.hb":
			
			String hotelID1 = request.getParameter("hotelId");
			String City = request.getParameter("city");
			String hotelname = request.getParameter("hotelName");
			String address = request.getParameter("address");
			String desp = request.getParameter("description");
			String nightRate3 = request.getParameter("nightRate");
			
			Float nightRate4 =Float.parseFloat(nightRate3);
			String phone1 = request.getParameter("phn1");
			String phone2 = request.getParameter("phn2");
			String rating1 = request.getParameter("rating");
			String email = request.getParameter("email");

			String fax1 = request.getParameter("fax");

			
			Hotel hotel1 = new Hotel();
			
			hotel1.setHotelId(hotelID1);
			hotel1.setCity(City);
			
			hotel1.setHotelName(hotelname);
			hotel1.setAddress(address);
			hotel1.setDescription(desp);
			hotel1.setAvgRatePerNight(nightRate4);
			hotel1.setPhoneNo1(phone1);
			hotel1.setPhoneNo2(phone2);
			hotel1.setRating(rating1);
			hotel1.setEmail(email);
			hotel1.setFax(fax1);


			
		
			
		hotelService.updateHotels(hotel1);
		
		url="Success.jsp";
			break;
		case "/viewUser.hb":
			List<Users>ulist=hotelService.showAll();
			request.setAttribute("ulist", ulist);
			url="ViewUserDetails.jsp";
		break;
		
		
		case "/addBooking.hb":
			//	HttpSession session1 = request.getSession();
				String id=request.getParameter("roomid");
				System.out.println("ID="+ id);
				RoomDetails room2=hotelService.getRoomDetails(id);
				System.out.println(room2);
				request.setAttribute("roomId",room2.getRoomId());
		      	request.setAttribute("roomno",room2.getRoomNo());
				request.setAttribute("roomtype",room2.getRoomType());
				request.setAttribute("pernightrate",room2.getPerNightRate());
				url="AddBooking.jsp";
				break;
				
			case "/addBookingRoom.hb":
				
				Float pernightrate = Float.parseFloat((request.getParameter("nightRate")));
			
				String id1 =request.getParameter("id");
				String date = request.getParameter("bookingdate");
				System.out.println(date);
				Date d1 = Date.valueOf(date);
				String roomId11=request.getParameter("roomid");
				
				
				String date2 = request.getParameter("tilldate");
				Date d2 = Date.valueOf(date);
				
				int noOfadults =Integer.parseInt(request.getParameter("noOfadults"));
				int noOfchildren = Integer.parseInt(request.getParameter("noOfChildren"));
				
				BookingDetails book = new BookingDetails();
				
				book.setAmount(pernightrate);
				book.setRoomId(roomId11);
				book.setUserId(id1);
				book.setBookedFrom(d1);
				book.setBookedTo(d2);
				book.setNoOfAdults(noOfadults);
				book.setNoOfChildren(noOfchildren);
				
				System.out.println(book);
				
				int bookId= hotelService.addBookingDetails(book);
				request.setAttribute("bookId", bookId);
	         System.out.println(bookId);
				url="UserSuccess.jsp";
				
				break;
				
				
			case"/getUserById.hb":
				String userId1=request.getParameter("txtUser");
				//HttpSession sess1=request.getSession(true);
				System.out.println("User id"+userId1);
				Users user1=hotelService.getUserDetails(userId1);
				System.out.println(user1);
				//System.out.println(sess1);
				request.setAttribute("user", user1);
				url="showUserDetailsById.jsp";
				break;
				
				
			case "/searchByCity.hb":
				
			
				String citySh = request.getParameter("cityS");
				
				List<Hotel> hbycitylist=hotelService.searchHotels(citySh);
				request.setAttribute("hbycitylist", hbycitylist);
				url="SearchByCity.jsp";
				
				
				break;
				
				
				

			case "/loginUser.hb":
			
				
				Users user2 = hotelService.getUserDetails("1001");
				System.out.println(user2);
				
				System.out.println(" In doPost of Login servlet.....");
				String un=request.getParameter("txtUnm");
				String pw=request.getParameter("txtPwd");
			
				try {
					if(hotelService.isUserExist(un))
					{
						System.out.println("isUserExist");
						Users user=hotelService.getUserDetails(un);
						System.out.println("in contrl scdd"+un+user);
						if(pw.equalsIgnoreCase(user.getPassword()))
						{
							System.out.println("pwd"+user.getPassword());
							url="UserHome.jsp";
							
						
						}
						else
						{
							request.getSession().setAttribute("error", "Sorry You are not valid user");

							RequestDispatcher rdFailure=
									request.getRequestDispatcher("ErrorPage.jsp");
							rdFailure.forward(request, response);

						}
						
						
					}
					else
					{
						RequestDispatcher rdUserNotExist = request.getRequestDispatcher("/Register.jsp");
						rdUserNotExist.forward(request, response);
					}
				} 
				catch (Exception e) 
				{
					// TODO Auto-generated catch block
					request.getSession().setAttribute("error", e.getMessage());
					
					
				}

					break;
					
			case "/addUser.hb":														//for Adding user details to Database
				
				String userName = request.getParameter("userName");
				String mobileNumber =request.getParameter("mobileNumber");
				String phone = request.getParameter("phone");
				String email1 = request.getParameter("email");
				String address1 = request.getParameter("address");
				String role = request.getParameter("role");
				String pswd = request.getParameter("password");
				
				Users users = new Users();
				
				users.setUsername(userName);
				users.setMobileNo(mobileNumber);
				users.setPhoneNo(phone);
				users.setEmail(email1);
				users.setAddress(address1);
				users.setRole(role);
				users.setPassword(pswd);
		
				try 
				{
					int userId=hotelService.addUSer(users);
				} 
				catch (HotelException e) 
				{
					request.getSession().setAttribute("error", e.getMessage());
					//e.printStackTrace();
				}
				
				HttpSession sessionU = request.getSession();
				sessionU.setAttribute("users",users);
				
				RequestDispatcher reqDis = getServletContext().getRequestDispatcher("/login.jsp");
				
			     reqDis.forward(request, response);
				
				break;
				
			case "/getUserdetails.hb":
				
				String username1=request.getParameter("userName");
				HttpSession usersession=request.getSession();
				usersession.setAttribute("username", username1);
				Users hoteldetails1 = hotelService.getUserDetails(username1);
				request.setAttribute("role", hoteldetails1.getRole());
				request.setAttribute("mobile", hoteldetails1.getMobileNo());
				request.setAttribute("phnnum", hoteldetails1.getPhoneNo());
				request.setAttribute("address", hoteldetails1.getAddress());
				request.setAttribute("email",hoteldetails1.getEmail());
				
				url="UpdateUserDetails.jsp";
				break;
				
			case "/processUpdateUser.hb":
				try{
				String role1 = request.getParameter("role");
				String mobileNumber1 = request.getParameter("mnum");
				String phonenum = request.getParameter("phonenum");
				String address2 = request.getParameter("address");

				String email2 = request.getParameter("email");

				HttpSession usersession1=request.getSession(false);
				String un1=(String)usersession1.getAttribute("username");
				
				
				System.out.println(email2);
				Users users1 = new Users();
				
				users1.setRole(role1);
				users1.setMobileNo(mobileNumber1);
				users1.setPhoneNo(phonenum);
				users1.setAddress(address2);
				users1.setEmail(email2);
				users1.setUsername(un1);
				System.out.println("in users "+users1);
				hotelService.updateUserDetails(users1);
			
			url="Success.jsp";

				break;
				}
				catch(Exception e)
				{
//					System.out.println(e.getMessage());
				}
				break;
		}
			
			
			
			
	
	
	
		RequestDispatcher rd = request.getRequestDispatcher(url) ;
		rd.forward(request, response);

}

}