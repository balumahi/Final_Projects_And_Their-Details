package com.capgemini.hms.junit;



import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.hms.DAO.HotelDaoImpl;
import com.capgemini.hms.dto.RoomDetails;
import com.capgemini.hms.service.HotelServiceImpl;
import com.capgemini.hms.service.IHotelService;


public class HotelTestCase

{
		IHotelService service;
	
	

	@BeforeClass
	public static void setUpBeforeClass() throws Exception 
	
	{
		
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception
	
	{
		
		
	}

	@Before
	public void setUp() throws Exception 
	
	{
		
		service= new HotelServiceImpl();
	}

	@After
	public void tearDown() throws Exception
	
	{
		
		
	}

	@Test
	public void testGetRoomDetails() 
	
	{
		
	    assertNotNull(service.getRoomDetails("1000"));
	}

}
