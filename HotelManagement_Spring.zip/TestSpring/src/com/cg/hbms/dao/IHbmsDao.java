package com.cg.hbms.dao;

import java.util.List;

import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.RoomDetails;
import com.cg.hbms.dto.Users;
import com.cg.hbms.exception.HotelException;

public interface IHbmsDao
{
	public int addHotel(Hotels hotel) throws HotelException;

	public int addUser(Users user) throws HotelException;

	public int addRoom(RoomDetails room) throws HotelException;

	public int addBooking(BookingDetails book) throws HotelException;
	
	public List<Hotels> showHotels() throws HotelException;

	public List<RoomDetails> showRooms() throws HotelException;

	public List<Users> showUsers() throws HotelException;

	public List<BookingDetails> showBookings() throws HotelException;

	public List<Hotels> searchHotels(String city) throws HotelException;
	
	public List<BookingDetails> viewMyBooking(int userId) throws HotelException;

	public List<RoomDetails> searchRooms(String roomType) throws HotelException;

	public void removeHotel(int hotelId) throws HotelException;

	public void removeRoom(int roomId) throws HotelException;
	
	public void removeBooking(int bookingId) throws HotelException;

	public List<Users> searchUsers(int userId) throws HotelException;

	public void updateHotel(Hotels hotel) throws HotelException;

	public Hotels searchHotelsId(int id) throws HotelException;

	public RoomDetails searchRoomsId(int id) throws HotelException;

	public void updateRoom(RoomDetails room) throws HotelException;
	
	public String getRole(String name, String pass) throws HotelException;
	
	public Users getUser(String name) throws HotelException;
	
	public void changePassword(Users user) throws HotelException;
	
	

}
