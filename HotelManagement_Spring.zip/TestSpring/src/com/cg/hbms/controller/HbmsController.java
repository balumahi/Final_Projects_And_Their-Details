package com.cg.hbms.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;




import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.RoomDetails;
import com.cg.hbms.dto.Users;
import com.cg.hbms.service.IHbmsService;

@Controller
public class HbmsController
{
	@Autowired
	IHbmsService hbmsService;
	
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String myLog(@ModelAttribute("data") Users user,HttpSession session)
	{
	
		
		return "login";
		
	}
	
	@RequestMapping(value="Login.do",method=RequestMethod.POST)
	public String myLogin(@RequestParam("name") String name , @RequestParam("pass") String pass,@ModelAttribute("data") Users user,HttpSession session)
	{
		String retPage = "error";
		//String role = hbmsService.getRole(name, pass);
		Users usr = hbmsService.getUser(name);
		String role=usr.getRole();
		System.out.println(usr);
		
		
		
		if(usr!=null)
		{
		if(pass.equalsIgnoreCase(usr.getPassword()))
		{
			if(role.equals("User"))
		
		{
				session.setAttribute("userName", name);
				session.setAttribute("userId", usr.getUserId());
				retPage = "userHome";
		}
		
		else if(role.equals("Employee"))
		{
			retPage = "userHome";
		}
		
		else if(role.equals("Admin"))
		{
			retPage = "index";
		}
		}
		}
		else
		{
			retPage = "error"; 
		}
		
		
		
		
		return retPage;
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addHotel(@ModelAttribute ("data") Hotels hotel, Map<String, Object> model)
	{
		List<String> ratingList = new ArrayList<String>();
		
		ratingList.add("One");
		ratingList.add("Two");
		ratingList.add("Three");
		ratingList.add("Four");
		ratingList.add("Five");
		
		model.put("rType", ratingList);
		return "addHotel";
	}
	
	@RequestMapping(value="addHotel", method=RequestMethod.POST)
	public ModelAndView hotelAdd(@ModelAttribute("data") Hotels hotel)
	{
		
		int id = hbmsService.addHotel(hotel);
		return new ModelAndView("success", "id", id);	
		
	}
	
	@RequestMapping(value="addU",method=RequestMethod.GET)
	public String addUser(@ModelAttribute ("data") Users user, Map<String, Object> model)
	{
		List<String> userList = new ArrayList<String>();
		
		userList.add("Employee");
		userList.add("User");
		userList.add("Admin");
		model.put("uType", userList);
		
		return "addUser";
	}
	
	@RequestMapping(value="addUser", method=RequestMethod.POST)
	public ModelAndView userAdd(@ModelAttribute("data") Users user)
	{
		
		int id = hbmsService.addUser(user);
		return new ModelAndView("successUser", "id", id);	
		
	}
	
	@RequestMapping(value="addR",method=RequestMethod.GET)
	public String addRoom(@ModelAttribute ("data") RoomDetails room, Map<String, Object> model, Map<String, Object> model1)
	{
		List<String> roomList = new ArrayList<String>();
		
		
		roomList.add("Single");
		roomList.add("Double");
		roomList.add("Triple");
		roomList.add("King");
		roomList.add("Queen");
		model.put("rType", roomList);
		
		List<String> roomList1 = new ArrayList<String>();
		
		roomList1.add("Yes");
		roomList1.add("No");
		
		model.put("avail", roomList1);
		
		return "addRoomDetails";
	}
	
	@RequestMapping(value="addRoom", method=RequestMethod.POST)
	public ModelAndView roomAdd(@ModelAttribute("data") RoomDetails room )
	{
		
		int id = hbmsService.addRoom(room);
		return new ModelAndView("successAddRoom", "id", id);	
		
	}
	
	@RequestMapping(value="addB",method=RequestMethod.GET)
	public String addBooking(@ModelAttribute ("data") BookingDetails book, Map<String, Object> model, Map<String, Object> model1)
	{
		List<String> bookingList = new ArrayList<String>();
		
		
		bookingList.add("1");
		bookingList.add("2");
		bookingList.add("3");
		bookingList.add("4");
		bookingList.add("5");
		bookingList.add("6");
		bookingList.add("7");
		bookingList.add("8");

		model.put("adults", bookingList);
		
		List<String> bookingList1 = new ArrayList<String>();
		
		bookingList1.add("0");
		bookingList1.add("1");
		bookingList1.add("2");
		bookingList1.add("3");
		bookingList1.add("4");
		bookingList1.add("5");

		model1.put("kids", bookingList1);
		
		return "addBooking";
	}
	
	@RequestMapping(value="Booking", method=RequestMethod.POST)
	public ModelAndView bookingAdd(@ModelAttribute("data") BookingDetails book)
	{	
		

		int id = hbmsService.addBooking(book);
		return new ModelAndView("viewUserBooking", "id", id);
	}


	@RequestMapping(value="bookRoom",method=RequestMethod.GET)
	public String addBookingOne(@ModelAttribute ("data") BookingDetails book, Map<String, Object> model, Map<String, Object> model1,@RequestParam("id") int id,@RequestParam("perRate") int rate,HttpSession sess)
	{

		sess.setAttribute("roomId", id);
		sess.setAttribute("nightrate", rate);
		List<String> bookingList = new ArrayList<String>();
		
		
		bookingList.add("1");
		bookingList.add("2");
		bookingList.add("3");
		bookingList.add("4");
		bookingList.add("5");
		bookingList.add("6");
		bookingList.add("7");
		bookingList.add("8");

		model.put("adults", bookingList);
		
		List<String> bookingList1 = new ArrayList<String>();
		
		bookingList1.add("0");
		bookingList1.add("1");
		bookingList1.add("2");
		bookingList1.add("3");
		bookingList1.add("4");
		bookingList1.add("5");

		model1.put("kids", bookingList1);
		
		return "addBooking";
	}
	
	@RequestMapping(value="showAllH",method=RequestMethod.GET)
	public ModelAndView dataShowH()
	{ List<Hotels> allData = hbmsService.showHotels();
		return new  ModelAndView("viewHotels","myListH",allData);
	}
	
	
	@RequestMapping(value="showAllR",method=RequestMethod.GET)
	public ModelAndView dataShowR()
	{ List<RoomDetails> allData = hbmsService.showRooms();
		return new  ModelAndView("viewRooms","myListR",allData);
	}
	
	@RequestMapping(value="showAllU",method=RequestMethod.GET)
	public ModelAndView dataShowU()
	{ List<Users> allData = hbmsService.showUsers();
		return new  ModelAndView("viewUsers","myListU",allData);
	}
	
	@RequestMapping(value="showAllB",method=RequestMethod.GET)
	public ModelAndView dataShowB()
	{ 
		List<BookingDetails> allData = hbmsService.showBookings();
		return new  ModelAndView("viewBooking","myListB",allData);
	}
	
	@RequestMapping(value="searchH",method=RequestMethod.GET)
	public String searchPage(@ModelAttribute("data") Hotels hotels)
	{
		return "searchHotels";
		
	}
	@RequestMapping(value="searchdataH",method=RequestMethod.POST)
	public ModelAndView searchData(@ModelAttribute("data") Hotels hotels)

	{
		String city = hotels.getCity();
		 List<Hotels> searchData= hbmsService.searchHotels(city);
		return new  ModelAndView("viewHotelsU","myListH",searchData);
	}
	
	@RequestMapping(value="searchR",method=RequestMethod.GET)
	public String searchPage(@ModelAttribute("data") RoomDetails rooms, Map<String, Object> model)
	{
		List<String> roomList = new ArrayList<String>();
		
		
		roomList.add("Single");
		roomList.add("Double");
		roomList.add("Triple");
		roomList.add("King");
		roomList.add("Queen");
		model.put("rType", roomList);
			
		return "searchRooms";
		
	}
	
	
	@RequestMapping(value="searchB",method=RequestMethod.GET)
	public ModelAndView searchMyBooking(@ModelAttribute("data") BookingDetails book, Map<String, Object> model,HttpSession session)
	{
		List<BookingDetails> myBookingData=null;
		
		try 
		{
			System.out.println("use  "+session.getAttribute("userId"));
			int userId=(int)session.getAttribute("userId");
			
			System.out.println("qwwejghj===>   "+userId);
			 
			myBookingData = hbmsService.viewMyBooking(userId);
		}
		catch (Exception e) 
		{
			return new  ModelAndView("error");
			
		}
		return new  ModelAndView("viewMyBookings","myBookingList",myBookingData);
		
	}
	
	
	@RequestMapping(value="searchdataR",method=RequestMethod.POST)
	public ModelAndView searchData(@ModelAttribute("data") RoomDetails rooms)

	{
		String roomType = rooms.getRoomType();
		 List<RoomDetails> searchRoom= hbmsService.searchRooms(roomType);
		return new  ModelAndView("viewRoomsU","myListR",searchRoom);
	}
	
	
	@RequestMapping(value="searchU",method=RequestMethod.GET)
	public String searchPage(@ModelAttribute("data") Users users, Map<String, Object> model)
	{
		List<String> userList1 = new ArrayList<String>();
		
		userList1.add("Employee");
		userList1.add("User");
		userList1.add("Admin");
		model.put("uType", userList1);
		
		
		
		return "searchUser";
		
	}
	@RequestMapping(value="searchdataU",method=RequestMethod.POST)
	public ModelAndView searchData(@ModelAttribute("data") Users users)

	{
		int userId  = users.getUserId();
		 List<Users> searchUser = hbmsService.searchUsers(userId);
		return new  ModelAndView("viewUsers","myListU",searchUser);
	}
	
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String deleteHotel(@RequestParam("id") int hotelId)
	{
		hbmsService.removeHotel(hotelId);
		return "viewHotels";
	}
	
	@RequestMapping(value="cancel",method=RequestMethod.GET)
	public ModelAndView removeBooking(@RequestParam("id") int bookingId)
	{
		hbmsService.removeBooking(bookingId);
		return new ModelAndView ("successCancelBooking","bookingId",bookingId);
	}
	
	@RequestMapping(value="deleteRoom",method=RequestMethod.GET)
	public String deleteRoom(@RequestParam("id") int roomId)
	{
		try 
		{
			hbmsService.removeRoom(roomId);
			
		}
		catch (Exception e) 
		{
			 return "ErrorDeleteRoom";
		}
		return "viewRooms";
	}
	
	@RequestMapping(value = "update", method = RequestMethod.GET )
	public String update(@RequestParam("id") int hotelId ,Map<String,Object> model, Map<String,Object> model1 , @ModelAttribute("data") Hotels hotel)
	{
		
		List<String> ratingList = new ArrayList<String>();
		
		ratingList.add("One");
		ratingList.add("Two");
		ratingList.add("Three");
		ratingList.add("Four");
		ratingList.add("Five");
		
		model.put("rType", ratingList);
		
		hotel = hbmsService.searchHotelsId(hotelId);
		model1.put("data",hotel);
		return "updateHotels";
		
	}

	@RequestMapping(value = "putdata" , method = RequestMethod.POST)
	public String updateData(@ModelAttribute("data")Hotels hotel)
	{
		hbmsService.updateHotel(hotel);
		return "redirect:/showAllH";
		
	}
	
	@RequestMapping(value = "updateRoom", method = RequestMethod.GET )
	public String updateRoom(@RequestParam("id") int roomId ,Map<String,Object> model, Map<String,Object> model1 , @ModelAttribute("data") RoomDetails room)
	{
		
		List<String> roomList = new ArrayList<String>();
		
		
		roomList.add("Single");
		roomList.add("Double");
		roomList.add("Triple");
		roomList.add("King");
		roomList.add("Queen");
		model.put("roomType", roomList);
		
		room = hbmsService.searchRoomsId(roomId);
		model1.put("data",room);
		return "updateRooms";
		
	}

	@RequestMapping(value = "putdataR" , method = RequestMethod.POST)
	public String updateDataR(@ModelAttribute("data")RoomDetails room)
	{
		hbmsService.updateRoom(room);
		return "redirect:/showAllR";
		
	}
	@RequestMapping("changePassword")
	public String changepassword(@RequestParam("oldPass")String oldPass,
			
		@RequestParam("newPass")String newPass,
		@RequestParam("confirmPass")String confirmPass,
		HttpSession session,Model model)
	{
		
		System.out.println(oldPass);
		String name=(String)session.getAttribute("userName");
		Users user=null;
		
		System.out.println(name+ " user" + user);
		try 
		{
			user=hbmsService.getUser(name);
			
			System.out.println(user);
	   
	   if(oldPass.equalsIgnoreCase(user.getPassword()))
	   {
		   System.out.println("valid Password");
	   
	   
	   if(newPass.equals(confirmPass))
	   {
		   System.out.println("equals Password");
		   user.setPassword(confirmPass);
		   hbmsService.changePassword(user);
		   return "successChangePassword";	   
	   
		}
		
		else
		{
			return "error";
		}
	   }
	   else
	   {
			return "error";

	   }
	
		}	catch (Exception e)
		{
			e.printStackTrace();
			model.addAttribute("errMsg","something went wrong");
			return "error";
		
		}
		
		
		 
		
		
			}
	@RequestMapping("exportReport")
	public String getReportPage(Model model)
	{
		 List<Hotels> bd = null;
		 List<RoomDetails> rd = null;
			try 
			{
				bd = hbmsService.showHotels();
				rd = hbmsService.showRooms();
				
				model.addAttribute("bd",bd);
				model.addAttribute("rd",rd);
			}
			catch (Exception e) 
			{
				e.getMessage();
			}
			return "Report";
	}
	
	@RequestMapping("generateReport")
	public String generateReport(Model model)
	{
		 List<Hotels> bd = null;
		try 
		{
			bd = hbmsService.showHotels();
			model.addAttribute("bd",bd);
			
		}
		catch (Exception e) 
		{
			e.getMessage();
		}
		return "SuccessReport";
		
	}
	
	@RequestMapping("generateReportRequest")
	public String getRequestReport(Model model)
	{
		List<RoomDetails> rd = null;
		try 
		{
			
			rd = hbmsService.showRooms();
			model.addAttribute("rd",rd);
		}
		catch (Exception e) 
		{
			e.getMessage();
		}
		
		return "SuccessReportR";
	}
	
	
			
	
	
	

	
	
	
	
	
}
