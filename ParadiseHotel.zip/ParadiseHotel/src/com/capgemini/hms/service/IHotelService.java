package com.capgemini.hms.service;

import java.util.List;

import com.capgemini.hms.Exception.HotelException;
import com.capgemini.hms.dto.BookingDetails;
import com.capgemini.hms.dto.Hotel;
import com.capgemini.hms.dto.RoomDetails;
import com.capgemini.hms.dto.Users;

public interface IHotelService
{
	
	
	//HotelDetails
   public int addHotel(Hotel hotel) throws HotelException;
	List<Hotel> showAllHotels() throws HotelException;
	public void updateHotels(Hotel hotel) throws HotelException;
	List<Hotel> searchHotels(String city) throws HotelException;
   public void removeHotel(String hotelId) throws HotelException;
   public Hotel getHotelDetails(String hotelId) throws HotelException;



	//RoomDetails
	List<RoomDetails> showAllRooms() throws HotelException;
	public int addRoomDetails(RoomDetails room) throws HotelException;
	 public void  updateRoomDetails(RoomDetails room) throws HotelException;
	public RoomDetails getRoomDetails(String roomId) throws HotelException;

	 
	//BookingDetails
		List<BookingDetails> showAllBookings() throws HotelException;
		public int addBookingDetails(BookingDetails book) throws HotelException;
		
		//UserDetails
		  public boolean isUserExist(String unm) throws HotelException;
		  public int addUSer(Users user) throws HotelException;
		  List<Users> showAll() throws HotelException;
		  public Users getUserDetails(String userId) throws HotelException;
}
