
create table Users (user_id varchar2(4), password varchar2(7), role varchar(10), 
user_name varchar2(20), mobile_no varchar2(10), phone varchar2(10), address varchar2(25), email  varchar2(15));

create table Hotel(hotel_id varchar2(4), city varchar2(10), hotel_name varchar2(20),address varchar2(25), 
description varchar2(50), avg_rate_perNight number(10,2),phone_no1 varchar2(10), phone_no2 varchar2(10), 
rating varchar2(4), email varchar2(15), fax varchar2(15));

create table RoomDetails(hotel_id varchar2(4),room_id varchar2(4),room_no varchar2(3),room_type varchar2(20),
per_night_rate number(6,2),availability char,photo varchar2(50));

create table BookingDetails (booking_id varchar2(4), room_id varchar2(4),user_id varchar2(4),booked_from date,
booked_to date, no_of_adults number, no_of_children number, amount number(6,2));

create sequence seqhotel start with 1000;

create sequence ROOM_HBMS_SEQ start with 1000;
create sequence USER_HBMS_SEQ start with 1000;
select * from BOOKINGDETAILS;

select * from HOTEL;
insert into ROOMDETAILS values('1001','101','201','deluxe',5000,'y','photo');
select * from ROOMDETAILS;

insert into BookingDETAILS values('1001','101','201','11-jan-2017','12-jan-2017',2,1,2000);

select * from BOOKINGDETAILS;
insert into Users values('101','pass','role','deep','9874562130','7894561230','delhi','desha@gmail.com');
select * from USERS;


create sequence  BOOKING_HBMS_SEQ start with 100;